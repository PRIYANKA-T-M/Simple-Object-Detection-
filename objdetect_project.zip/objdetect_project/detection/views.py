from django.shortcuts import render
from ultralytics import YOLO
import os

model = YOLO('yolov8n.pt')  # Make sure yolov8n.pt is in your project folder

def index(request):
    result_img = None

    if request.method == 'POST' and request.FILES.get('image'):
        image = request.FILES['image']
        image_path = os.path.join('media', image.name)

        # Save the uploaded image
        with open(image_path, 'wb+') as destination:
            for chunk in image.chunks():
                destination.write(chunk)

        # Run object detection
        results = model(image_path)
        results[0].save(filename='detection/static/result.jpg')  # Save detected image
        result_img = 'result.jpg'

    return render(request, 'detection/index.html', {'result_img': result_img})
